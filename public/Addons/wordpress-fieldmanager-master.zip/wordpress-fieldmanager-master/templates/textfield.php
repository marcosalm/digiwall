<input
	class="fm-element"
	type="text"
	name="<?php echo $this->get_form_name(); ?>"
	id="<?php echo $this->get_element_id(); ?>"
	value="<?php echo htmlspecialchars( $value ); ?>"
	<?php echo $this->get_element_attributes(); ?>
/>