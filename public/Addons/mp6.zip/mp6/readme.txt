=== MP6 ===
Contributors: matt, EmpireOfLight, melchoyce, isaackeyet, drw158, azaozz, helen, Joen, lessbloat, iammattthomas, saracannon, Viper007Bond, nickmomrik, apeatling, koopersmith, apeatling, tillkruess, mitchoyoshitaka
Tags: iteration
Requires at least: 3.7
Tested up to: 3.7.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Stable tag: trunk

This is a plugin to break the wp-admin UI, and is not recommended for non-savvy users.


== Description ==

This plugin is a secret; don't tell anybody about it. Don't use it with WordPress 3.8 or higher.

Simplifying the wp-admin UI is a challenging task, as flattening the icons showed us when you improve one thing it just makes all of the other out of date elements stand out more.

Trunk isn't terribly well-suited for UI iteration, so this plugin is a chance for us to rapidly iterate in a way people can use and test some new ideas for how to visually tie together the aesthetics of our current wp-admin UI.

Existence of this plugin will be officially denied, but discussion will happen at http://make.wordpress.org/ui/ if you'd like to participate. All comments and contributions are welcome, though we're leaving the final call on decisions to MT.

(MP6 doesn't stand for anything.)


== Changelog ==

http://plugins.trac.wordpress.org/log/mp6/